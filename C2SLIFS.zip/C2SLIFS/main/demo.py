import copy
import numpy as np

from main.common import GraphDAG
from main.metrics import MetricsDAG
from main.datasets import DAG, IIDSimulation
from main.algorithms import CSL

weighted_random_dag = DAG.erdos_renyi(n_nodes=10, n_edges=10, weight_range=(0.5, 2.0), seed=1)
dataset = IIDSimulation(W=weighted_random_dag, n=2000, method='nonlinear', sem_type='mlp')
true_dag, X = dataset.B, dataset.X

ER = X.shape[1] / np.sum(np.reshape(true_dag, (true_dag.size,)))
E_R = np.sum(np.reshape(true_dag, (true_dag.size,))) / (X.shape[1]+np.sum(np.reshape(true_dag, (true_dag.size,))))

batch_size = 100
cycle_index = 10
'''
from cdt.data import load_dataset
s_data, s_graph = load_dataset('sachs')
X = s_data[0:853]
true_dag = nx.to_numpy_array(s_graph)
'''
csl = CSL(model_type='nn',iter_step=100,rho_thresh=1e20,init_rho=1e-5,
          rho_multiply=10,graph_thresh=5.0001e-1,l1_graph_penalty=2e-3)
csl.learn(X, pns_mask=true_dag)

# plot est_dag and true_dag
GraphDAG(csl.causal_matrix, true_dag)

# calculate accuracy
met = MetricsDAG(csl.causal_matrix, true_dag)
print(met.metrics)

fluedata = 1
i = 0
while fluedata < cycle_index:

    Xi = X[batch_size * i:batch_size * (i + 1)]

    csl = CSL(model_type='nn', iter_step=100, rho_thresh=1e20, init_rho=1e-5,
              rho_multiply=10, graph_thresh=5.0001e-1, l1_graph_penalty=2e-3)
    csl.learn(Xi, pns_mask=true_dag)

    # plot est_dag and true_dag
    GraphDAG(csl.causal_matrix, true_dag)

    if fluedata == 1:
        new_dag = csl.causal_matrix
    else:
        old_dag = copy.deepcopy(new_dag)
        new_dag = csl.causal_matrix

    if fluedata > 1:
        dif1_dag = new_dag - old_dag
        for m in range(0, X.shape[1]):
            for n in range(0, X.shape[1]):
                if dif1_dag[m][n] == 1:
                    dif1_dag[m][n] = 1
                else:
                    dif1_dag[m][n] = 0

    dif_dag = new_dag - sum_dag
    for m in range(0, X.shape[1]):
        for n in range(0, X.shape[1]):
            if dif_dag[m][n] == 1:
                dif_dag[m][n] = 1
            else:
                dif_dag[m][n] = 0

    if fluedata > 1:
        sum_dag = sum_dag + new_dag + dif_dag * fluedata * E_R + dif1_dag * ER * fluedata * 1 / (
            np.log(cycle_index)) * (1 - E_R)

    else:
        sum_dag = sum_dag + new_dag + dif_dag * fluedata * E_R

    dag = copy.deepcopy(sum_dag)
    for m in range(0, X.shape[1]):
        for n in range(0, X.shape[1]):
            if sum_dag[m][n] / (fluedata + 1) >= 0.5:
                dag[m][n] = 1
            else:
                dag[m][n] = 0

    fluedata += 1
    i += 1
    met = MetricsDAG(dag, true_dag)
    print(met.metrics)